
type 'a stack = 'a MyList.list
let empty = MyList.empty
let push x xs = MyList.insert
let pop = MyList.tail
let top = MyList.head

 